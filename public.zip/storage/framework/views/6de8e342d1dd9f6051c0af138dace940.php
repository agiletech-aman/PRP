<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label', 'value', 'href' => null, 'hint' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label', 'value', 'href' => null, 'hint' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => 'stat stat-link'])); ?>>
<?php else: ?>
    <div <?php echo e($attributes->merge(['class' => 'stat'])); ?>>
<?php endif; ?>
        <span class="stat-label"><?php echo e($label); ?></span>
        <span class="stat-value"><?php echo e($value); ?></span>
        <?php if(filled((string) $hint)): ?>
            <span class="stat-hint"><?php echo e($hint); ?></span>
        <?php endif; ?>
<?php if($href): ?>
    </a>
<?php else: ?>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Aman\Appraisel-Portal\resources\views/components/stat.blade.php ENDPATH**/ ?>