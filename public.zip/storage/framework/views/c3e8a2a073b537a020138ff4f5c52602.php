<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'label', 'for' => null, 'required' => false, 'hint' => null, 'full' => false, 'bag' => 'default']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'label', 'for' => null, 'required' => false, 'hint' => null, 'full' => false, 'bag' => 'default']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $errorKey = str_replace(['[', ']'], ['.', ''], $name);
    $fieldErrors = $errors->getBag($bag);
?>

<div <?php echo e($attributes->class(['field', 'field-full' => $full, 'has-error' => $fieldErrors->has($errorKey)])); ?>>
    <label for="<?php echo e($for ?? $name); ?>">
        <?php echo e($label); ?>

        <?php if($required): ?><span class="required" aria-hidden="true">*</span><?php endif; ?>
    </label>

    <?php echo e($slot); ?>


    <?php if($fieldErrors->has($errorKey)): ?>
        <p class="field-error"><?php echo e($fieldErrors->first($errorKey)); ?></p>
    <?php elseif($hint): ?>
        <p class="field-hint"><?php echo e($hint); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH D:\xampp\htdocs\Aman\Appraisel-Portal\resources\views/components/field.blade.php ENDPATH**/ ?>