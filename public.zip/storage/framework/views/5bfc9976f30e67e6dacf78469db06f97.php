<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'My Appraisals','subtitle' => 'Your own appraisals and the ones you review as a manager']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Appraisals','subtitle' => 'Your own appraisals and the ones you review as a manager']); ?>
    <div class="card card-flush">
        <table class="table">
            <thead>
                <tr><th>Appraisal</th><th>Employee</th><th>Your part</th><th>Sent</th><th>Status</th><th class="actions-col">Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $appraisals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appraisal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($stage = $appraisal->ratingStageFor(auth()->user())); ?>
                    <tr>
                        <td><strong><?php echo e($appraisal->title); ?></strong></td>
                        <td><?php echo e($appraisal->employee->name); ?></td>
                        <td><?php echo e(auth()->id() === $appraisal->employee_id ? 'Self-rating' : 'Manager rating'); ?></td>
                        <td><?php echo e($appraisal->sent_at?->format('d M Y') ?? '—'); ?></td>
                        <td>
                            <?php if($stage): ?>
                                <span class="pill pill-warn">Your action needed</span>
                            <?php else: ?>
                                <span class="pill <?php echo e($appraisal->status->pillClass()); ?>"><?php echo e($appraisal->status->label()); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="actions">
                                <?php if($stage): ?>
                                    <a href="<?php echo e(route('admin.appraisals.show', $appraisal)); ?>" class="btn btn-primary btn-sm">Fill form</a>
                                <?php else: ?>
                                    <?php if (isset($component)) { $__componentOriginalf3e2e88103a43e9e072739ac6625d63a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-link','data' => ['href' => route('admin.appraisals.show', $appraisal),'icon' => 'eye','label' => 'View']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.appraisals.show', $appraisal)),'icon' => 'eye','label' => 'View']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $attributes = $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $component = $__componentOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="empty">You have no appraisals yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Aman\Appraisel-Portal\resources\views/admin/appraisals/mine.blade.php ENDPATH**/ ?>