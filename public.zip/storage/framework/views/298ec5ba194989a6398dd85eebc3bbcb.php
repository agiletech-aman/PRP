<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Send appraisal','subtitle' => 'The mail goes to each employee, with their reporting manager in CC']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Send appraisal','subtitle' => 'The mail goes to each employee, with their reporting manager in CC']); ?>
    <a href="<?php echo e(route('admin.appraisals.index')); ?>" class="back-link"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> All appraisals</a>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.appraisals.create')); ?>" class="inline-form filters">
            <div class="search-input">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search name, code or email" aria-label="Search employees">
            </div>
            <select name="department" onchange="this.form.submit()" aria-label="Filter by department">
                <option value="">All departments</option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>" <?php if((string) request('department') === (string) $department->id): echo 'selected'; endif; ?>><?php echo e($department->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if(request()->hasAny(['search', 'department'])): ?>
                <a href="<?php echo e(route('admin.appraisals.create')); ?>" class="btn btn-ghost">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <form method="POST" action="<?php echo e(route('admin.appraisals.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="card mb">
            <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'title','label' => 'Appraisal title','required' => true,'hint' => 'Shown in the mail subject and on the form, e.g. “Annual Appraisal 2026”.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Appraisal title','required' => true,'hint' => 'Shown in the mail subject and on the form, e.g. “Annual Appraisal 2026”.']); ?>
                <input id="title" type="text" name="title" value="<?php echo e(old('title', $defaultTitle)); ?>" required maxlength="255">
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
        </div>

        <div class="card card-flush">
            <table class="table">
                <thead>
                    <tr>
                        <th class="select-col">
                            <input type="checkbox" id="select-all" aria-label="Select all eligible employees">
                        </th>
                        <th>Employee</th><th>Department</th><th>Reporting manager (CC)</th><th>Can send?</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $blockedReason = match (true) {
                                $employee->department === null => 'No department',
                                $employee->manager === null => 'No reporting manager',
                                ! $employee->manager->is_active => 'Manager is inactive',
                                (bool) $employee->has_open_appraisal => 'Appraisal in progress',
                                default => null,
                            };
                        ?>
                        <tr>
                            <td class="select-col">
                                <input type="checkbox" name="employee_ids[]" value="<?php echo e($employee->id); ?>" class="employee-check"
                                       aria-label="Select <?php echo e($employee->name); ?>"
                                       <?php if(in_array($employee->id, array_map('intval', old('employee_ids', [])), true)): echo 'checked'; endif; ?>
                                       <?php if($blockedReason !== null): echo 'disabled'; endif; ?>>
                            </td>
                            <td>
                                <div class="person">
                                    <span class="avatar avatar-sm"><?php echo e($employee->initials()); ?></span>
                                    <div>
                                        <strong><?php echo e($employee->name); ?></strong>
                                        <div class="muted small"><?php echo e($employee->employee_code); ?> · <?php echo e($employee->email); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($employee->department?->name ?? '—'); ?></td>
                            <td>
                                <?php if($employee->manager): ?>
                                    <?php echo e($employee->manager->name); ?>

                                    <div class="muted small"><?php echo e($employee->manager->email); ?></div>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($blockedReason): ?>
                                    <span class="pill pill-gray"><?php echo e($blockedReason); ?></span>
                                <?php else: ?>
                                    <span class="pill pill-green">Ready</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="empty">No active employees match these filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="form-actions sticky-actions">
            <span class="muted" id="selected-count">0 selected</span>
            <button type="submit" class="btn btn-primary">Send appraisal mail</button>
        </div>
    </form>

    <script>
        (() => {
            const selectAll = document.getElementById('select-all');
            const counter = document.getElementById('selected-count');
            const checks = () => [...document.querySelectorAll('.employee-check:not(:disabled)')];
            const refresh = () => {
                const selected = checks().filter((box) => box.checked).length;
                counter.textContent = `${selected} selected`;
                selectAll.checked = selected > 0 && selected === checks().length;
            };

            selectAll.addEventListener('change', () => {
                checks().forEach((box) => { box.checked = selectAll.checked; });
                refresh();
            });
            checks().forEach((box) => box.addEventListener('change', refresh));
            refresh();
        })();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Aman\Appraisel-Portal\resources\views/admin/appraisals/create.blade.php ENDPATH**/ ?>