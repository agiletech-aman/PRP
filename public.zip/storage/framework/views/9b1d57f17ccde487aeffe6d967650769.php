<?php
    $employee = $appraisal->employee;
    $employeeAverage = $appraisal->averageRating('employee');
    $managerAverage = $appraisal->averageRating('manager');
    $editableColumn = $stage ? $stage.'_rating' : null;
?>

<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => $appraisal->title,'subtitle' => $employee->name.' · '.($appraisal->department?->name ?? $employee->department?->name ?? 'No department').' · ratings out of '.\App\Models\Appraisal::MAX_RATING]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appraisal->title),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employee->name.' · '.($appraisal->department?->name ?? $employee->department?->name ?? 'No department').' · ratings out of '.\App\Models\Appraisal::MAX_RATING)]); ?>
    <a href="<?php echo e(auth()->user()->can(\App\PermissionName::SendAppraisals->value) ? route('admin.appraisals.index') : route('admin.appraisals.mine')); ?>" class="back-link">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-left']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Back to appraisals
    </a>

    <div class="stats">
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'Status','value' => $appraisal->status->label(),'hint' => 'Sent '.($appraisal->sent_at?->format('d M Y') ?? '—')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Status','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appraisal->status->label()),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Sent '.($appraisal->sent_at?->format('d M Y') ?? '—'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'Employee','value' => $employee->name,'hint' => $employee->employee_code.' · '.($employee->designation ?? '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Employee','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employee->name),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employee->employee_code.' · '.($employee->designation ?? ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'Reporting manager','value' => $appraisal->manager?->name ?? '—','hint' => $appraisal->manager?->designation]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Reporting manager','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appraisal->manager?->name ?? '—'),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($appraisal->manager?->designation)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3b387acd2c997737a257e1ec014549fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b387acd2c997737a257e1ec014549fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat','data' => ['label' => 'Average (self / manager)','value' => ($employeeAverage ?? '—').' / '.($managerAverage ?? '—')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Average (self / manager)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($employeeAverage ?? '—').' / '.($managerAverage ?? '—'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $attributes = $__attributesOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__attributesOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b387acd2c997737a257e1ec014549fd)): ?>
<?php $component = $__componentOriginal3b387acd2c997737a257e1ec014549fd; ?>
<?php unset($__componentOriginal3b387acd2c997737a257e1ec014549fd); ?>
<?php endif; ?>
    </div>

    <?php if($stage === 'employee'): ?>
        <div class="alert alert-info">Rate yourself on every factor, then submit. Your manager will add their ratings after you.</div>
    <?php elseif($stage === 'manager'): ?>
        <div class="alert alert-info"><?php echo e($employee->name); ?> has submitted their self-rating. Add your manager rating for every factor, then submit.</div>
    <?php elseif($appraisal->status === \App\AppraisalStatus::Pending && auth()->id() === $appraisal->manager_id): ?>
        <div class="alert alert-info">Waiting for <?php echo e($employee->name); ?> to submit their self-rating. You will get a mail when it is your turn.</div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.appraisals.update', $appraisal)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="card card-flush">
            <table class="table appraisal-table">
                <thead>
                    <tr class="appraisal-title"><th>Sr. No.</th><th colspan="3">Rating Factors Out of <?php echo e(\App\Models\Appraisal::MAX_RATING); ?> Rating.</th></tr>
                </thead>
                <?php ($serial = 0); ?>
                <?php $__empty_1 = true; $__currentLoopData = $ratingsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ratings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tbody>
                        <tr class="appraisal-heading">
                            <th><?php echo e($ratings->first()->category_code); ?>.</th>
                            <th><?php echo e($ratings->first()->category_name); ?>:</th>
                            <th>Employee Rating</th>
                            <th>Manager Rating</th>
                        </tr>
                        <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="center"><?php echo e(++$serial); ?></td>
                                <td><?php echo e($rating->factor_name); ?></td>
                                <?php $__currentLoopData = ['employee_rating', 'manager_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="<?php echo \Illuminate\Support\Arr::toCssClasses(['center', 'has-error' => $column === $editableColumn && $errors->has("ratings.{$rating->id}")]); ?>">
                                        <?php if($column === $editableColumn): ?>
                                            <select name="ratings[<?php echo e($rating->id); ?>]" class="rating-select" required aria-label="Rating for <?php echo e($rating->factor_name); ?>">
                                                <option value="">Select</option>
                                                <?php for($value = 1; $value <= \App\Models\Appraisal::MAX_RATING; $value++): ?>
                                                    <option value="<?php echo e($value); ?>" <?php if((string) old("ratings.{$rating->id}") === (string) $value): echo 'selected'; endif; ?>><?php echo e($value); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        <?php else: ?>
                                            <span class="rating-value"><?php echo e($rating->{$column} ?? '—'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tbody><tr><td colspan="4" class="muted">This appraisal has no rating factors.</td></tr></tbody>
                <?php endif; ?>
                <?php if($ratingsByCategory->isNotEmpty()): ?>
                    <tfoot>
                        <tr class="appraisal-total">
                            <td></td>
                            <td>Average rating</td>
                            <td class="center"><?php echo e($employeeAverage ?? '—'); ?></td>
                            <td class="center"><?php echo e($managerAverage ?? '—'); ?></td>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>

        <div class="card">
            <div class="card-head"><h2>Remarks</h2><span class="muted small">Optional</span></div>
            <div class="field-grid">
                <?php $__currentLoopData = ['employee' => 'Employee remarks', 'manager' => 'Manager remarks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentStage => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($stage === $commentStage): ?>
                        <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'comments','label' => $label]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'comments','label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label)]); ?>
                            <textarea id="comments" name="comments" rows="4" maxlength="2000" placeholder="Optional: add your remarks"><?php echo e(old('comments')); ?></textarea>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
                    <?php else: ?>
                        <div class="field">
                            <label><?php echo e($label); ?></label>
                            <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['comment-text', 'muted' => blank($appraisal->{$commentStage.'_comments'})]); ?>"><?php echo e($appraisal->{$commentStage.'_comments'} ?: 'No remarks.'); ?></p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <?php if($stage): ?>
            <div class="form-actions sticky-actions">
                <span class="muted">Ratings cannot be changed after submitting.</span>
                <button type="submit" class="btn btn-primary" onclick="return confirm('Submit your ratings? You cannot change them afterwards.')">
                    Submit <?php echo e($stage === 'employee' ? 'self-rating' : 'manager rating'); ?>

                </button>
            </div>
        <?php endif; ?>
    </form>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addHrRemarks', $appraisal)): ?>
        <form method="POST" action="<?php echo e(route('admin.appraisals.hr-remarks', $appraisal)); ?>" class="card">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-head">
                <h2>HR remarks</h2>
                <span class="muted small">
                    Optional · can be updated at any stage
                    <?php if($appraisal->hr_remarked_at): ?>
                        · last saved by <?php echo e($appraisal->hrRemarksAuthor?->name ?? 'HR'); ?> on <?php echo e($appraisal->hr_remarked_at->format('d M Y')); ?>

                    <?php endif; ?>
                </span>
            </div>
            <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'hr_remarks','label' => 'Remarks','for' => 'hr_remarks']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hr_remarks','label' => 'Remarks','for' => 'hr_remarks']); ?>
                <textarea id="hr_remarks" name="hr_remarks" rows="4" maxlength="2000" placeholder="Optional: add HR remarks"><?php echo e(old('hr_remarks', $appraisal->hr_remarks)); ?></textarea>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
            <div class="form-actions">
                <button type="submit" class="btn btn-outline">Save HR remarks</button>
            </div>
        </form>
    <?php elseif(filled($appraisal->hr_remarks)): ?>
        <div class="card">
            <div class="card-head"><h2>HR remarks</h2></div>
            <p class="comment-text"><?php echo e($appraisal->hr_remarks); ?></p>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Aman\Appraisel-Portal\resources\views/admin/appraisals/show.blade.php ENDPATH**/ ?>